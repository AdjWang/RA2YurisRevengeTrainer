#ifndef __TRAINERFUNCTIONS_H__
#define __TRAINERFUNCTIONS_H__
#pragma once
#include "trainerbase.h"


class TrainerFunctions : public TrainerBase
{
public:
	void writem();
	void buidQ();
	void lookMap();
	static void full_mqp();
	void allMap();
	void winOver();
	static void full_fir();
	void DYcall();
	static void level_all();
	void levelCall();
	static void ad_all();
	void adCall();
	static void zeroAsm();
	void zeroL();
	void freeAE();
	DWORD money();
	static void NO1_all();
	void No1();
};

#endif
