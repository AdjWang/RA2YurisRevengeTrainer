#include "stdafx.h"
#include "trainerfunctions.h"


void TrainerFunctions::writem() //��Ǯ�޸�99999
{
	writeMemory(readMemory(0x00A35DB4)+0x24C,99999); //ʵ�ʽ�Ǯ��ַ
	writeMemory(0x008373D0,99999);        //������ʾ��Ǯ��ַ
}

void TrainerFunctions::buidQ() //���ٽ���
{
	int j=0;
	getID();
	for(int i=1;i<=5;(j+=4),i++)
	{
		writeMemory(readMemory(0x00A35DB4)+j+0x52b8,15);
	}
}

void TrainerFunctions::lookMap() //��ѵ�ͼ
{
	getID();
	writeMemory(readMemory(0x00A3D290)+0x2228,0x1,0x1);
}

//ȫ��ͼ��������
void TrainerFunctions::full_mqp()
{
	_asm
	{
		pushad
			mov ecx,0x008324E0
			mov ebx,0x0055A120
			call ebx
			popad                       
	}
}
void TrainerFunctions::allMap()
{
	//��ͼȫ��
	writProcess(full_mqp);
}

void TrainerFunctions::winOver() //����ʤ��
{
	getID();
	writeMemory(0x00A35DB1,0x1,0x1);
}

//����˵���������
void TrainerFunctions::full_fir()
{
	int edx_one;       
	__asm
	{
		pushad
			//��һ��call
			mov ecx,0x14
			mov edx_one,0x0069F7E0
			call edx_one
			mov eax,0x0A4033C        //Ϊ�˵õ�eax
			mov eax,[eax]                //C++��Ȼ��һ
		mov eax,[eax]                //��Call��ֵ
		mov ebx,eax                        //�����ݸ��¸�

			//�ڶ���call(�����˵�ʱ��CD)
			add ebx,0x98                //����
			mov eax,[ebx]                //���               
		mov edx,0x00A35DB4
			mov edx,[edx]
		mov ecx,edx
			add ecx,0x1A0
			mov ecx,[ecx]
		push 0                //��ʼ״̬��1=�ȴ�
			push 0                //��Ӧ����               
			mov ecx,[ecx+eax*4]
		//mov ecx,[ecx]
		//lea ecx,[ecx+eax*4]
		push 1        //1=һ���Ի��ᡣ��Ϸ������⣬�˵�����=1�������������               
			mov edx_one,0x0069CCF0
			call edx_one

			//������Call ���Ӻ˵�ѡ��
			mov ebx,0x0A4033C       
			mov ebx,[ebx]               
		mov ebx,[ebx]               
		mov eax,ebx
			add ebx,0x98       
			mov eax,[ebx]
		mov ecx,0x008324E0
			push eax
			push 0x1F
			mov edx_one,0x0067C530
			call edx_one
			popad               
	}       
}

void TrainerFunctions::DYcall()
{
	//����˵�
	writProcess(full_fir);
}

//��λ�����������
void TrainerFunctions::level_all()
{
	int shuliang;
	int jizhi;
	__asm
	{
		push eax
			mov  eax,0x00A40C70        //0x00A40C70����
			mov eax,[eax]
		mov shuliang,eax
			mov eax,0x00A40C64        //0x00A40C64��ַ
			mov eax,[eax]
		mov jizhi,eax
			pop eax
	}
	while (shuliang != 0)
	{
		__asm
		{
			pushad
				mov eax,jizhi                                                       
				mov edx,[eax]
			add edx,0x11C
				mov ebx,0x40000000
				mov [edx],ebx        //���� float 2
				popad                               
		}
		shuliang = shuliang -1;
		jizhi = jizhi + 4;
	}
}

void TrainerFunctions::levelCall()
{
	//��λ����
	writProcess(level_all);
}

//���������������
void TrainerFunctions::ad_all()
{
	int shuliang;
	int jizhi;
	__asm
	{
		push eax
			mov  eax,0x00A40C70        //0x00A40C70����
			mov eax,[eax]
		mov shuliang,eax
			mov eax,0x00A40C64        //0x00A40C64��ַ
			mov eax,[eax]
		mov jizhi,eax
			pop eax
	}
	while (shuliang != 0)
	{

		__asm
		{
			pushad
				mov eax,jizhi                                                       
				mov edx,[eax]

			add edx,0x11C
				mov ebx,0x40000000
				mov [edx],ebx        //���� float 2

				mov edx,[eax]
			add edx,0x128
				mov ebx,0x3FF80000
				mov [edx],ebx        //���� float 1.5

				mov edx,[eax]
			add edx,0x130
				mov ebx,0x40000000
				mov [edx],ebx        //���� float 2
				popad

		}
		shuliang = shuliang -1;
		jizhi = jizhi + 4;
	}

}

void TrainerFunctions::adCall()
{
	//��������
	writProcess(ad_all);
}

__declspec(naked) void TrainerFunctions::zeroAsm()
{
	__asm
	{
		push eax
			mov eax,00A35DB4h
			mov eax,[eax]
		cmp eax,esi
			jnz originalcode
			mov [esi+52D4h],0
			jmp exit1
originalcode:
		mov [esi+52D4h],ecx
exit1:
		pop eax
//		jmp 004F2DA1h
	}
}

void TrainerFunctions::zeroL() //����Ϊ0
{
	DWORD sizeX;
	char i[10];
	getID();        //get process HANDLE
	//callbase = VirtualAllocEx(pid,NULL,0x256,MEM_COMMIT,PAGE_EXECUTE_READWRITE);
	virtualAE(&callbase);        //VirtualAllocEx
	sprintf_s(i,"%x",callbase);
	OutputDebugString(i);
	jmpWritProc((LPVOID)0x004F2D9B,callbase); //jmp write address
	writeMemory((DWORD)callbase,(DWORD)zeroAsm,256);
	writeMemory((0x004F2D9B+5),0x90,1);		//0x90->nop
	WriteProcessMemory(pid,callbase,&zeroAsm,256,&sizeX);
	jmpWritProc((LPVOID)((int)callbase +28),(LPVOID)0x004F2DA1);
}

void TrainerFunctions::freeAE() //�ر����޵���
{       
	getID();
	DWORD add_l = 0x004F2D9B;
	BYTE jmp_l[6] ={137,142,212,82,0,0};
	DWORD writex = WriteProcessMemory(pid,(LPVOID)add_l,&jmp_l,sizeof(jmp_l),0);
	::VirtualFreeEx(pid,callbase,0,MEM_RELEASE);
	callbase=0;
}

DWORD TrainerFunctions::money() //��ȡ��Ǯ
{
	return readMemory(0x00A35DB4,0X24C);
}

//ѡ���޵�
void TrainerFunctions::NO1_all()
{
	int shuliang;
	int jizhi;
	__asm
	{
		push eax
			mov  eax,0x00A40C70        //0x00A40C70����
			mov eax,[eax]
		mov shuliang,eax
			mov eax,0x00A40C64        //0x00A40C64��ַ
			mov eax,[eax]
		mov jizhi,eax
			pop eax
	}
	while (shuliang != 0)
	{
		__asm
		{
			pushad
				mov eax,jizhi                                                       
				mov edx,[eax]
			add edx,0x157
				mov ebx,0x64
				mov [edx],ebx        //ѡ���޵�
				popad                               
		}
		shuliang = shuliang -1;
		jizhi = jizhi + 4;
	}
}
void TrainerFunctions::No1()
{
	writProcess(NO1_all);
}